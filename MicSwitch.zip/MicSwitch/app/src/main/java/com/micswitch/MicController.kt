package com.micswitch

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import kotlin.math.sqrt

enum class MicSource { PHONE, HEADSET }

@Suppress("DEPRECATION")
class MicController(private val ctx: Context) {

    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val prefs = ctx.getSharedPreferences("mic", Context.MODE_PRIVATE)

    private val headsetTypes = setOf(
        AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_USB_HEADSET,
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
        AudioDeviceInfo.TYPE_BLE_HEADSET
    )

    fun saved(): MicSource =
        if (prefs.getString("src", "PHONE") == "HEADSET") MicSource.HEADSET else MicSource.PHONE

    fun auto() = prefs.getBoolean("auto", false)
    fun setAuto(v: Boolean) = prefs.edit().putBoolean("auto", v).apply()
    fun bubble() = prefs.getBoolean("bubble", false)
    fun setBubble(v: Boolean) = prefs.edit().putBoolean("bubble", v).apply()
    fun serviceNeeded() = auto() || bubble()

    private fun inputs() = am.getDevices(AudioManager.GET_DEVICES_INPUTS).toList()

    fun phoneMic(): AudioDeviceInfo? = inputs().firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
    fun headsetMic(): AudioDeviceInfo? = inputs().firstOrNull { it.type in headsetTypes }
    fun hasHeadset() = headsetMic() != null

    fun deviceFor(src: MicSource) = if (src == MicSource.PHONE) phoneMic() else headsetMic()

    /** Sistem-wide routing try karta hai. Result ek Hindi message hai. */
    fun apply(src: MicSource): String {
        prefs.edit().putString("src", src.name).apply()
        if (src == MicSource.HEADSET && !hasHeadset()) {
            return "हेडफोन नहीं मिला, पहले हेडफोन लगाओ"
        }
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val target = am.availableCommunicationDevices.firstOrNull {
                if (src == MicSource.PHONE) it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                else it.type in headsetTypes
            }
            if (target != null && am.setCommunicationDevice(target)) {
                if (src == MicSource.PHONE) "फ़ोन का माइक चालू" else "हेडफोन का माइक चालू"
            } else "स्विच नहीं हो पाया, इस फ़ोन में सीमा है"
        } else {
            if (src == MicSource.PHONE) {
                am.stopBluetoothSco(); am.isBluetoothScoOn = false; am.isSpeakerphoneOn = true
                "फ़ोन का माइक चालू"
            } else {
                am.isSpeakerphoneOn = false
                if (am.isBluetoothScoAvailableOffCall) { am.startBluetoothSco(); am.isBluetoothScoOn = true }
                "हेडफोन का माइक चालू"
            }
        }
    }

    fun reset() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) am.clearCommunicationDevice()
        am.mode = AudioManager.MODE_NORMAL
    }

    /** टेस्ट: चुने हुए माइक से आवाज़ का लेवल 0..1 */
    @SuppressLint("MissingPermission")
    fun levels(src: MicSource): Flow<Float> = flow {
        val rate = 16000
        val size = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, rate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size * 2
        )
        deviceFor(src)?.let { rec.preferredDevice = it }
        val buf = ShortArray(size)
        try {
            rec.startRecording()
            while (currentCoroutineContext().isActive) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) {
                    var sum = 0.0
                    for (i in 0 until n) sum += buf[i] * buf[i].toDouble()
                    emit((sqrt(sum / n) / 5000.0).toFloat().coerceIn(0f, 1f))
                }
            }
        } finally {
            rec.stop(); rec.release()
        }
    }.flowOn(Dispatchers.IO)
}
