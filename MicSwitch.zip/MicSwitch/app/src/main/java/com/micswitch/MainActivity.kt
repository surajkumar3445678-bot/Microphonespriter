package com.micswitch

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Base = Color(0xFF0E0F1F)
private val Purple = Color(0xFF9C7BFF)
private val Green = Color(0xFF2EE6A8)
private val Dim = Color(0xFFB8B5D6)
private val Glass = Color(0x14FFFFFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Purple, surface = Color(0xFF1C1B2E))) {
                MicScreen()
            }
        }
    }
}

@Composable
fun MicScreen() {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val mic = remember { MicController(ctx) }
    var source by remember { mutableStateOf(mic.saved()) }
    var hasHeadset by remember { mutableStateOf(mic.hasHeadset()) }
    var status by remember { mutableStateOf("एक माइक चुनो") }
    var testing by remember { mutableStateOf(false) }
    var auto by remember { mutableStateOf(mic.auto()) }
    var bubble by remember { mutableStateOf(mic.bubble() && FloatingService.running) }
    val history = remember { mutableStateListOf<Float>().apply { repeat(28) { add(0f) } } }
    var permOk by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { permOk = it }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    DisposableEffect(Unit) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val cb = object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(a: Array<out AudioDeviceInfo>?) {
                hasHeadset = mic.hasHeadset(); source = mic.saved()
            }
            override fun onAudioDevicesRemoved(r: Array<out AudioDeviceInfo>?) {
                hasHeadset = mic.hasHeadset()
            }
        }
        am.registerAudioDeviceCallback(cb, null)
        onDispose { am.unregisterAudioDeviceCallback(cb) }
    }

    LaunchedEffect(testing, source, permOk) {
        if (testing && permOk) {
            mic.levels(source).collect { history.removeAt(0); history.add(it) }
        } else {
            for (i in history.indices) history[i] = 0f
        }
    }

    fun syncService() {
        val i = Intent(ctx, FloatingService::class.java)
        if (mic.serviceNeeded()) ContextCompat.startForegroundService(ctx, i) else ctx.stopService(i)
    }
    fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    fun choose(s: MicSource) {
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        source = s; status = mic.apply(s)
    }

    val accent by animateColorAsState(if (source == MicSource.PHONE) Purple else Green, label = "accent")
    val bg = Brush.verticalGradient(listOf(Base, accent.copy(alpha = 0.20f).compositeOver(Base), Base))

    val inf = rememberInfiniteTransition(label = "pulse")
    val pulse by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "p")

    Box(Modifier.fillMaxSize().background(bg)) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("माइक स्विच", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("एक टैप में माइक बदलो", color = Dim, fontSize = 14.sp)
                }
                Row(
                    Modifier.clip(RoundedCornerShape(50)).background(Glass).padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(if (hasHeadset) Green else Color(0xFFFF6B6B)))
                    Spacer(Modifier.width(7.dp))
                    Text(if (hasHeadset) "हेडफोन जुड़ा" else "हेडफोन नहीं", color = Color.White, fontSize = 12.sp)
                }
            }

            // हीरो: धड़कते घेरे + बड़ा आइकन
            Box(Modifier.size(230.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    for (k in 0..2) {
                        val t = (pulse + k / 3f) % 1f
                        drawCircle(
                            color = accent.copy(alpha = (1f - t) * 0.40f),
                            radius = size.minDimension / 2 * (0.52f + 0.48f * t),
                            style = Stroke(width = 3.dp.toPx())
                        )
                    }
                }
                Box(
                    Modifier.size(126.dp).clip(CircleShape).background(accent),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (source == MicSource.PHONE) Icons.Filled.PhoneAndroid else Icons.Filled.Headset,
                        null, tint = Base, modifier = Modifier.size(62.dp)
                    )
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    if (source == MicSource.PHONE) "फ़ोन का माइक" else "हेडफोन का माइक",
                    color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold
                )
                Text(status, color = accent, fontSize = 14.sp, textAlign = TextAlign.Center)
            }

            // स्लाइडिंग स्विच
            BoxWithConstraints(
                Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(30.dp)).background(Glass).padding(5.dp)
            ) {
                val half = maxWidth / 2
                val off by animateDpAsState(if (source == MicSource.PHONE) 0.dp else half, label = "off")
                Box(Modifier.offset(x = off).width(half).fillMaxHeight().clip(RoundedCornerShape(26.dp)).background(accent))
                Row(Modifier.fillMaxSize()) {
                    Seg("फ़ोन", Icons.Filled.PhoneAndroid, source == MicSource.PHONE, true, Modifier.weight(1f)) { choose(MicSource.PHONE) }
                    Seg("हेडफोन", Icons.Filled.Headset, source == MicSource.HEADSET, hasHeadset, Modifier.weight(1f)) { choose(MicSource.HEADSET) }
                }
            }

            // टेस्ट कार्ड: वेवफ़ॉर्म
            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconDot(Icons.Filled.GraphicEq, accent)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("माइक टेस्ट", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        Text("बोलो, लहरें हिलें तो माइक चल रहा है", color = Dim, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Canvas(Modifier.fillMaxWidth().height(60.dp)) {
                    val n = history.size
                    val gap = 4.dp.toPx()
                    val w = (size.width - gap * (n - 1)) / n
                    val minH = 6.dp.toPx()
                    history.forEachIndexed { i, v ->
                        val h = minH + v * (size.height - minH)
                        drawRoundRect(
                            color = accent.copy(alpha = 0.35f + 0.65f * v),
                            topLeft = Offset(i * (w + gap), (size.height - h) / 2),
                            size = Size(w, h),
                            cornerRadius = CornerRadius(w / 2)
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = {
                        if (!permOk) permLauncher.launch(Manifest.permission.RECORD_AUDIO) else testing = !testing
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Base)
                ) {
                    Icon(if (testing) Icons.Filled.Stop else Icons.Filled.Mic, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (testing) "टेस्ट बंद करो" else "टेस्ट शुरू करो", fontWeight = FontWeight.SemiBold)
                }
            }

            // ऑटो + फ़्लोटिंग
            GlassCard {
                SettingRow(
                    Icons.Filled.Bolt, accent, "हेडफोन लगते ही फ़ोन का माइक",
                    "तार लगाते ही अपने-आप फ़ोन का माइक चुन लो", auto
                ) { on ->
                    auto = on; mic.setAuto(on)
                    if (on) askNotif()
                    syncService()
                }
                Spacer(Modifier.height(14.dp))
                HorizontalDivider(color = Color(0x22FFFFFF))
                Spacer(Modifier.height(14.dp))
                SettingRow(
                    Icons.Filled.BubbleChart, accent, "फ़्लोटिंग बटन",
                    "दूसरे ऐप के ऊपर से भी माइक बदलो", bubble
                ) { on ->
                    if (on && !Settings.canDrawOverlays(ctx)) {
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } else {
                        bubble = on; mic.setBubble(on)
                        if (on) askNotif()
                        syncService()
                    }
                }
            }

            TextButton(onClick = { mic.reset(); status = "फ़ोन की डिफ़ॉल्ट सेटिंग पर वापस" }) {
                Icon(Icons.Filled.RestartAlt, null, tint = Dim)
                Spacer(Modifier.width(6.dp))
                Text("रीसेट करो", color = Dim)
            }
            Text(
                "ध्यान: Samsung में तार वाला हेडफोन लगते ही कुछ ऐप हेडफोन का माइक खुद पकड़ लेते हैं। हर ऐप में स्विच न चले तो यह फ़ोन की सीमा है।",
                color = Color(0xFF8E8BB0), fontSize = 11.sp, textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun Seg(label: String, icon: ImageVector, selected: Boolean, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val c = when {
        selected -> Base
        enabled -> Color.White
        else -> Color(0x66FFFFFF)
    }
    Row(
        modifier.fillMaxHeight().clip(RoundedCornerShape(26.dp)).clickable(enabled = enabled, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = c, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, color = c, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}

@Composable
private fun GlassCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Glass).padding(18.dp),
        content = content
    )
}

@Composable
private fun IconDot(icon: ImageVector, tint: Color) {
    Box(
        Modifier.size(42.dp).clip(CircleShape).background(tint.copy(alpha = 0.18f)),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp)) }
}

@Composable
private fun SettingRow(icon: ImageVector, tint: Color, title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconDot(icon, tint)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = Dim, fontSize = 12.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = tint, checkedThumbColor = Base)
        )
    }
}
