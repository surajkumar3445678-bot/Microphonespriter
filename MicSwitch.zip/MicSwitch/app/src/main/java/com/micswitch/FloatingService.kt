package com.micswitch

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class FloatingService : Service() {

    companion object { @Volatile var running = false }

    private lateinit var wm: WindowManager
    private lateinit var am: AudioManager
    private lateinit var mic: MicController
    private var bubble: TextView? = null

    private val cb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>?) {
            if (mic.auto() && mic.hasHeadset()) {
                val msg = mic.apply(MicSource.PHONE)
                bubble?.let { paint(it) }
                Toast.makeText(this@FloatingService, "हेडफोन लगा। $msg", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        mic = MicController(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        startAsForeground()
        am.registerAudioDeviceCallback(cb, null)
        sync()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        sync()
        return START_STICKY
    }

    private fun sync() {
        if (mic.bubble()) { if (bubble == null) addBubble() } else removeBubble()
        if (mic.auto() && mic.hasHeadset()) {
            mic.apply(MicSource.PHONE)
            bubble?.let { paint(it) }
        }
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("mic", "Mic Switch", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "mic")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("माइक स्विच चालू है")
            .setContentText("हेडफोन लगते ही फ़ोन का माइक / फ़्लोटिंग बटन")
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun paint(v: TextView) {
        val phone = mic.saved() == MicSource.PHONE
        v.text = if (phone) "📱" else "🎧"
        v.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (phone) Color.parseColor("#6750A4") else Color.parseColor("#0B8F6B"))
            setStroke(4, Color.WHITE)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addBubble() {
        val size = (60 * resources.displayMetrics.density).toInt()
        val v = TextView(this).apply {
            textSize = 26f
            gravity = Gravity.CENTER
            elevation = 12f
        }
        paint(v)
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 400 }

        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y; touchX = e.rawX; touchY = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt(); val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    lp.x = startX + dx; lp.y = startY + dy
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    val next = if (mic.saved() == MicSource.PHONE) MicSource.HEADSET else MicSource.PHONE
                    val msg = mic.apply(next)
                    paint(v)
                    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                }
            }
            true
        }
        wm.addView(v, lp)
        bubble = v
    }

    private fun removeBubble() {
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
    }

    override fun onDestroy() {
        am.unregisterAudioDeviceCallback(cb)
        removeBubble()
        running = false
        super.onDestroy()
    }
}
