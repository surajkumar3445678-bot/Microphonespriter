APK बनाने के 2 तरीके:

1) Android Studio: फ़ोल्डर खोलो -> Build -> Build APK(s).
2) फ़ोन से ही: GitHub पर नया repo बनाओ, यह पूरा फ़ोल्डर upload करो,
   Actions टैब में "Build APK" चलेगा, खत्म होने पर Artifacts से MicSwitch-apk डाउनलोड करो.

ऐप खोलकर: माइक की अनुमति दो, फ़्लोटिंग बटन चालू करो (overlay अनुमति देनी होगी).
